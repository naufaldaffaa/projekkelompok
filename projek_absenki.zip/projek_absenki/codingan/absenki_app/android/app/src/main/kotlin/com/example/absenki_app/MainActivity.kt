package com.example.absenki_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
