import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:intl/intl.dart';

class KalenderPendidikanPage extends StatefulWidget {
  const KalenderPendidikanPage({super.key});

  @override
  State<KalenderPendidikanPage> createState() => _KalenderPendidikanPageState();
}

class _KalenderPendidikanPageState extends State<KalenderPendidikanPage> {
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;
  String _selectedMonth = DateFormat('MMMM yyyy', 'id_ID').format(DateTime.now());

  // Data kalender pendidikan berdasarkan bulan (Juli 2024 - Juni 2025)
  final Map<String, List<Map<String, dynamic>>> _kalenderPendidikan = {
    'Juli 2024': [
      {'tanggal': 1, 'keterangan': 'Persiapan Tahun Ajaran Baru'},
      {'tanggal': 15, 'keterangan': 'Hari Pertama Masuk Sekolah'},
    ],
    'Agustus 2024': [
      {'tanggal': 17, 'keterangan': 'Hari Kemerdekaan Indonesia'},
    ],
    'September 2024': [
      {'tanggal': 25, 'keterangan': 'Ujian Tengah Semester (UTS)'},
    ],
    'Oktober 2024': [
      {'tanggal': 2, 'keterangan': 'Hari Batik Nasional'},
      {'tanggal': 28, 'keterangan': 'Hari Sumpah Pemuda'},
    ],
    'November 2024': [
      {'tanggal': 10, 'keterangan': 'Hari Pahlawan'},
    ],
    'Desember 2024': [
      {'tanggal': 20, 'keterangan': 'Libur Semester Ganjil'},
      {'tanggal': 25, 'keterangan': 'Hari Natal'},
    ],
    'Januari 2025': [
      {'tanggal': 1, 'keterangan': 'Tahun Baru 2025'},
      {'tanggal': 15, 'keterangan': 'Awal Semester Genap'},
    ],
    'Februari 2025': [
      {'tanggal': 28, 'keterangan': 'Ujian Sekolah (Try Out)'},
    ],
    'Maret 2025': [
      {'tanggal': 17, 'keterangan': 'Ujian Akhir Sekolah'},
      {'tanggal': 30, 'keterangan': 'Libur Akhir Ujian'},
    ],
    'April 2025': [
      {'tanggal': 1, 'keterangan': 'Awal Ujian Nasional'},
    ],
    'Mei 2025': [
      {'tanggal': 20, 'keterangan': 'Hari Kebangkitan Nasional'},
    ],
    'Juni 2025': [
      {'tanggal': 10, 'keterangan': 'Pengumuman Kelulusan'},
      {'tanggal': 25, 'keterangan': 'Akhir Tahun Ajaran'},
    ],
  };

  @override
  Widget build(BuildContext context) {
    final today = DateTime.now();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red,
        title: const Text(
          'Kalender Pendidikan',
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Dropdown Pilih Bulan (Juli 2024 - Juni 2025)
            DropdownButtonFormField<String>(
              value: _selectedMonth,
              items: _kalenderPendidikan.keys.map((bulan) {
                final isCurrentMonth = bulan == DateFormat('MMMM yyyy', 'id_ID').format(today);
                return DropdownMenuItem(
                  value: bulan,
                  child: RichText(
                    text: TextSpan(
                      text: bulan,
                      style: const TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                      ),
                      children: isCurrentMonth
                          ? [
                              const TextSpan(
                                text: ' (Bulan Ini)',
                                style: TextStyle(
                                  color: Colors.grey, // Warna abu-abu untuk "(Bulan Ini)"
                                  fontWeight: FontWeight.normal,
                                ),
                              ),
                            ]
                          : [],
                    ),
                  ),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _selectedMonth = value!;
                  _focusedDay = DateFormat('MMMM yyyy', 'id_ID').parse(_selectedMonth);
                });
              },
              decoration: InputDecoration(
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Kalender
            TableCalendar(
              firstDay: DateTime(2024, 7, 1),
              lastDay: DateTime(2025, 6, 30),
              focusedDay: _focusedDay,
              selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
              onDaySelected: (selectedDay, focusedDay) {
                setState(() {
                  _selectedDay = selectedDay;
                  _focusedDay = focusedDay;
                });
              },
              calendarStyle: CalendarStyle(
                todayDecoration: const BoxDecoration(
                  color: Colors.red,
                  shape: BoxShape.circle,
                ),
                selectedDecoration: const BoxDecoration(
                  color: Colors.blue,
                  shape: BoxShape.circle,
                ),
                markerDecoration: const BoxDecoration(
                  color: Colors.green,
                  shape: BoxShape.circle,
                ),
              ),
              headerVisible: false, // Menghilangkan navigasi bulan < >
            ),
            const SizedBox(height: 20),

            // Keterangan Hari di bawah kalender (Tampil sesuai bulan yang dipilih)
            Expanded(
              child: ListView(
                children: _kalenderPendidikan[_selectedMonth]?.map((event) {
                      return Container(
                        margin: const EdgeInsets.symmetric(vertical: 5),
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade200,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Colors.grey.shade300),
                        ),
                        child: Text(
                          '${event['tanggal']} - ${event['keterangan']}',
                          style: const TextStyle(fontSize: 16),
                        ),
                      );
                    }).toList() ??
                    [
                      const Center(
                        child: Padding(
                          padding: EdgeInsets.all(10.0),
                          child: Text(
                            'Tidak ada keterangan untuk bulan ini.',
                            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                          ),
                        ),
                      )
                    ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
